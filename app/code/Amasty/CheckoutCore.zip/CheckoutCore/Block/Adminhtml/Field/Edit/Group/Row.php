<?php
/**
* @author Amasty Team
* @copyright Copyright (c) 2022 Amasty (https://www.amasty.com)
* @package Amasty_CheckoutCore
*/


namespace Amasty\CheckoutCore\Block\Adminhtml\Field\Edit\Group;

use Magento\Framework\Data\Form\Element\AbstractElement;

class Row extends AbstractElement
{
}
