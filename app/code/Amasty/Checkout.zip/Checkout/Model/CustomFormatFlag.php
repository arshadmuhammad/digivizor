<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_Checkout
 */


namespace Amasty\Checkout\Model;

/**
 * Class CustomFormatFlag
 */
class CustomFormatFlag
{
    /**
     * @var bool
     */
    public static $flag = true;
}
