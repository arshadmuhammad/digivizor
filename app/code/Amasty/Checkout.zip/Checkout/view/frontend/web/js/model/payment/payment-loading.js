define([
    'ko'
], function (ko) {
    'use strict';

    /**
     * Loader for payment block
     * @see payment-service-mixin.js
     */
    return ko.observable(false);
});
